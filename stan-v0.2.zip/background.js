chrome.browserAction.onClicked.addListener(function (tab) { //Fired when User Clicks ICON
    window.open("https://chrome.google.com/webstore/detail/stan-enhancer/cjapkagcaocenhiaggfloccbknckndpf","_blank");
});