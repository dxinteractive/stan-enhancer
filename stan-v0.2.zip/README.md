# stan-enhancer
Chrome extension to add IMDB and RT scores to Stan
